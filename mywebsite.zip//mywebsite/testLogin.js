$(document).ready(function(){
   /* hide the error message for wrong username input till when needed */
   $("#message").hide();   
  });

/* match both the password inputs for sign up */
function matchpass(){
				var firstpassword=document.f1.password1.value ;
				var secondpassword=document.f1.password2.value;
 
  if(firstpassword==secondpassword){
   return true; 
   }
  
   else
   { alert("password must be same!"); 
   
   return false;
    } 
}






/* Set the width of the side navigation to 250px */
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

/* Set the width of the side navigation to 0 */
function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}